package com.mini.foodiescorner;

public class uriModel3 {
    String imageUrl2;
    String food_name;
    String rupees;

    public uriModel3(String imageUrl2, String food_name, String rupees) {
        this.imageUrl2 = imageUrl2;
        this.food_name = food_name;
        this.rupees = rupees;
    }

    public String getImageUrl2() {
        return imageUrl2;
    }

    public void setImageUrl2(String imageUrl2) {
        this.imageUrl2 = imageUrl2;
    }

    public String getFood_name() {
        return food_name;
    }

    public void setFood_name(String food_name) {
        this.food_name = food_name;
    }

    public String getRupees() {
        return rupees;
    }

    public void setRupees(String rupees) {
        this.rupees = rupees;
    }
}

