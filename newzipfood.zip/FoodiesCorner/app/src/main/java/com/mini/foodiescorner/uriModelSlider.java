package com.mini.foodiescorner;

public class uriModelSlider {
    String imageUrl;

    public uriModelSlider(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }
}
